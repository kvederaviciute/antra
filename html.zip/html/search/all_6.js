var searchData=
[
  ['operator_3c_3c_0',['operator&lt;&lt;',['../class_student.html#a3927a6e81bf7a6bbb4a2322f13f4ac0e',1,'Student']]],
  ['operator_3d_1',['operator=',['../class_student.html#ad05dd6148523a2a8b38128b60297b52a',1,'Student']]],
  ['operator_3e_3e_2',['operator&gt;&gt;',['../class_student.html#a32b1c2a3e1ebcfea4bc12270cb8bca98',1,'Student']]]
];
