var searchData=
[
  ['operator_3c_3c_0',['operator&lt;&lt;',['../class_student.html#a3927a6e81bf7a6bbb4a2322f13f4ac0e',1,'Student']]],
  ['operator_3e_3e_1',['operator&gt;&gt;',['../class_student.html#a32b1c2a3e1ebcfea4bc12270cb8bca98',1,'Student']]]
];
