var searchData=
[
  ['zmogus_0',['Zmogus',['../class_zmogus.html#aa7a8ba4d3c4778f9b35d59eef3e72574',1,'Zmogus::Zmogus()'],['../class_zmogus.html#ae6bfb71e4c8fddf15f3a19b4bcd6fd26',1,'Zmogus::Zmogus(const std::string &amp;vardas, const std::string &amp;pavarde)']]]
];
