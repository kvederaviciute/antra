var searchData=
[
  ['setegzaminas_0',['setEgzaminas',['../class_student.html#a717450a29535a960c86ad27f4c638fe5',1,'Student']]],
  ['setpavarde_1',['setPavarde',['../class_zmogus.html#ae4c3b02e68af5ed87c68101ba699539c',1,'Zmogus']]],
  ['setvardas_2',['setVardas',['../class_zmogus.html#a6024e8fb5c3a9fbd48ca522f976f8465',1,'Zmogus']]],
  ['skirstymas1_3',['Skirstymas1',['../class_student.html#a6c619141b975a3f245de8ebf720eae5a',1,'Student']]],
  ['skirstymas2_4',['Skirstymas2',['../class_student.html#a2fcaa7faa1740c6102d82f0ccd352cf1',1,'Student']]],
  ['skirstymas3_5',['Skirstymas3',['../class_student.html#ad84733d37b3c07da088b48ed23bf5335',1,'Student']]],
  ['student_6',['Student',['../class_student.html#af9168cedbfa5565cf0b20c1a9d3f5c9d',1,'Student::Student()'],['../class_student.html#a9a2d11bd6de5a948f550f29e6389d03f',1,'Student::Student(const std::string &amp;vardas, const std::string &amp;pavarde)'],['../class_student.html#a05b37ffb050ddb039db63a8764d790cb',1,'Student::Student(const Student &amp;other)']]]
];
