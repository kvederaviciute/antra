var searchData=
[
  ['pagrindas_2eh_0',['pagrindas.h',['../pagrindas_8h.html',1,'']]]
];
