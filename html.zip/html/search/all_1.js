var searchData=
[
  ['cleardata_0',['clearData',['../class_student.html#a72675eaf7f5a82fb53c2d71b6f5c7ca0',1,'Student']]]
];
