var searchData=
[
  ['vidurkis_0',['Vidurkis',['../class_student.html#a1b5ec147bf22ad05421740bd68297c8a',1,'Student']]]
];
