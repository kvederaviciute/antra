var searchData=
[
  ['isvedimas_0',['Isvedimas',['../class_student.html#a430774a7b5cb93be0fb41ce43e8d1fa2',1,'Student']]],
  ['ivedimas_1',['Ivedimas',['../class_student.html#a01bb728fef01a49e84c9c4cb376ca37f',1,'Student']]]
];
