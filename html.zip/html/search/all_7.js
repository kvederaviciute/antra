var searchData=
[
  ['pagrindas_2eh_0',['pagrindas.h',['../pagrindas_8h.html',1,'']]],
  ['pavarde_1',['pavarde',['../class_zmogus.html#a99cc96defe5d014db052cc754e989b16',1,'Zmogus']]],
  ['printinfo_2',['printInfo',['../class_zmogus.html#a9b368ebb8e59bd80d93cb772799cdfea',1,'Zmogus::printInfo()'],['../class_student.html#af0c3a85247c39646dbcdae19afe562a2',1,'Student::printInfo()']]]
];
