var searchData=
[
  ['galutinismed_0',['Galutinismed',['../class_student.html#afa9a6b99782f31b8aedcd7c589e2e46a',1,'Student']]],
  ['galutinisvid_1',['GalutinisVid',['../class_student.html#ae2102a6b848f793b6c1072407fe516dd',1,'Student']]],
  ['getgalutinismed_2',['getGalutinisMed',['../class_student.html#a9007f565cb1b22647de958a614db60f4',1,'Student']]],
  ['getgalutinisvid_3',['getGalutinisVid',['../class_student.html#a2f0a3c5628b6028e15f0c4a59f15d013',1,'Student']]],
  ['getpavarde_4',['getPavarde',['../class_zmogus.html#ac50d1e325af387bb385eb88bb7ff42b7',1,'Zmogus']]],
  ['getvardas_5',['getVardas',['../class_zmogus.html#a4a580af3507a2d27efe978d5be0075ab',1,'Zmogus']]]
];
