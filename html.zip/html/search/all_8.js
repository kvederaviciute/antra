var searchData=
[
  ['rikiavimas_0',['Rikiavimas',['../class_student.html#a73e1dfa0e954875dd60e16c962622bed',1,'Student']]]
];
