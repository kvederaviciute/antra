var searchData=
[
  ['pavarde_0',['pavarde',['../class_zmogus.html#a99cc96defe5d014db052cc754e989b16',1,'Zmogus']]]
];
