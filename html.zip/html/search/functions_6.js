var searchData=
[
  ['operator_3d_0',['operator=',['../class_student.html#ad05dd6148523a2a8b38128b60297b52a',1,'Student']]]
];
