var searchData=
[
  ['addnamudarbai_0',['addNamudarbai',['../class_student.html#ad340c498af1537138f1dec26b3debc82',1,'Student']]]
];
