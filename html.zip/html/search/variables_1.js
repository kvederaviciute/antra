var searchData=
[
  ['vardas_0',['vardas',['../class_zmogus.html#a4d456bf4fea70f08e0b26517576cfbc0',1,'Zmogus']]]
];
