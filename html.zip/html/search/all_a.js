var searchData=
[
  ['vardas_0',['vardas',['../class_zmogus.html#a4d456bf4fea70f08e0b26517576cfbc0',1,'Zmogus']]],
  ['vidurkis_1',['Vidurkis',['../class_student.html#a1b5ec147bf22ad05421740bd68297c8a',1,'Student']]]
];
