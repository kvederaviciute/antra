var searchData=
[
  ['ndbe_0',['NdBe',['../class_student.html#ad852bc61f4903946b7790d3dda88e360',1,'Student']]],
  ['ndrandom_1',['NdRandom',['../class_student.html#a76eda4e2690ce14cf8eff0e20e5ecd36',1,'Student']]],
  ['ndsu_2',['NdSu',['../class_student.html#a95a14a1f542c3e8e963aba7342db811d',1,'Student']]]
];
